'use client'

import { BellIcon as Bell, ListIcon as List } from '@phosphor-icons/react'
import { Button } from '@/components/ui/button'
import { useSidebar } from '@/components/ui/sidebar'
import { useAuth } from '@/features/auth/hooks/useAuth'
import { Breadcrumb } from './Breadcrumb'

export function Header() {
  const { user } = useAuth()
  const { toggleSidebar } = useSidebar()

  const initials = user?.fullName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2) ?? 'U'

  return (
    <header className="h-12 bg-card border-b border-border/70 flex items-center px-3 gap-3 sticky top-0 z-30">
      <Button
        variant="ghost"
        size="icon"
        onClick={toggleSidebar}
          className="h-7 w-7 text-muted-foreground hover:text-foreground hover:bg-muted shrink-0"
        aria-label="Toggle sidebar"
      >
        <List size={18} weight="bold" />
      </Button>

      <div className="flex-1 min-w-0">
        <Breadcrumb />
      </div>

      <div className="flex items-center gap-1 shrink-0">
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-muted-foreground hover:text-foreground hover:bg-muted relative"
          aria-label="Notifications"
        >
          <Bell size={18} />
          <span className="absolute top-1 right-1 w-2 h-2 bg-primary rounded-full border-2 border-card" />
        </Button>

        <div className="hidden sm:flex items-center gap-1.5 pl-2 ml-1 border-l border-border/70">
          <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center">
            <span className="text-xs font-semibold text-primary">{initials}</span>
          </div>
          <div className="hidden md:flex flex-col leading-none">
            <span className="text-xs font-semibold text-foreground">{user?.fullName}</span>
            <span className="text-[10px] text-muted-foreground capitalize">
              {user?.role.replace(/_/g, ' ')}
            </span>
          </div>
        </div>
      </div>
    </header>
  )
}
