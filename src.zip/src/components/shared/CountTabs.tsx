import type { ReactNode } from "react";
import Link from "next/link";
import { cn } from "@/lib/utils";
import { tabItemClassName, tabRowClassName } from "@/components/shared/tabs/tab-style";

interface CountTabItem {
  label: string;
  value: ReactNode;
  active?: boolean;
  href?: string;
  onClick?: () => void;
}

interface CountTabsProps {
  items: CountTabItem[];
  className?: string;
}

export function CountTabs({ items, className }: CountTabsProps) {
  return (
    <div className={cn(tabRowClassName, className)}>
      {items.map((item) => {
        const content = (
          <>
            <span className="truncate">{item.label}</span>
            <span
              className={cn(
                "rounded-full px-1.5 py-0.5 text-[10px] font-semibold",
                item.active ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground",
              )}
            >
              {item.value}
            </span>
          </>
        );

        const itemClassName = cn(tabItemClassName(Boolean(item.active)), "max-w-full");

        if (item.href) {
          return (
            <Link key={item.label} href={item.href} data-active={item.active} className={itemClassName}>
              {content}
            </Link>
          );
        }

        return (
          <button
            key={item.label}
            type="button"
            data-active={item.active}
            className={itemClassName}
            onClick={item.onClick}
          >
            {content}
          </button>
        );
      })}
    </div>
  );
}
