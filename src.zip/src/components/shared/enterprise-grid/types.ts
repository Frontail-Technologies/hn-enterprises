import type { ReactNode } from "react";

export type EnterpriseColumn<T extends { id: string }> = {
  key: string;
  label: string;
  width?: number;
  minWidth?: number;
  maxWidth?: number;
  grow?: boolean;
  pin?: boolean;
  enableResizing?: boolean;
  enableSorting?: boolean;
  getValue: (row: T) => string | number | boolean | null | undefined;
  getFilterGroups?: (row: T) => string[];
  render?: (row: T) => ReactNode;
};

export interface EnterpriseDataGridSelection<T extends { id: string }> {
  selectedIds: ReadonlySet<string>;
  onToggleRow: (id: string) => void;
  onTogglePage: (ids: string[]) => void;
  getRowLabel?: (row: T) => string;
}

export type EnterpriseFilterValues = Record<string, string[]>;
