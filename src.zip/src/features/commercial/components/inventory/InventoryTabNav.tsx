import { CountTabs } from "@/components/shared/CountTabs";
import type { InventoryTab } from "../../types/commercial.types";

const TAB_LABELS: Record<InventoryTab, string> = {
  stock: "Stock Sheet",
  purchase: "Purchase Register",
  pbgIssue: "PBG Issue",
  pbgConsumption: "PBG Consumption",
  storeIssue: "Store Issue Book",
  totalIssue: "Total Issue",
  plumberBalance: "Plumber Balance",
  plumberConsumption: "Consumption Log",
};

const TAB_ORDER: InventoryTab[] = [
  "stock",
  "purchase",
  "pbgIssue",
  "pbgConsumption",
  "storeIssue",
  "totalIssue",
  "plumberBalance",
  "plumberConsumption",
];

export function InventoryTabNav({
  activeTab,
  onChange,
  counts,
}: {
  activeTab: InventoryTab;
  onChange: (tab: InventoryTab) => void;
  counts: Partial<Record<InventoryTab, number>>;
}) {
  return (
    <CountTabs
      items={TAB_ORDER.map((tab) => ({
        label: TAB_LABELS[tab],
        value: counts[tab] ?? 0,
        active: activeTab === tab,
        onClick: () => onChange(tab),
      }))}
    />
  );
}
