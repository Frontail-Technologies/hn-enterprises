import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { usersApi, type CreateUserFormValues, type UpdateUserFormValues } from "../services/users.service";

const usersKey = ["users", "full"] as const;
const userKey = (id: string) => ["users", id] as const;

export function useUsersQuery(search?: string) {
  return useQuery({
    queryKey: [...usersKey, search ?? ""],
    queryFn: () => usersApi.listFull(search),
  });
}

export function useCreateUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (values: CreateUserFormValues) => usersApi.create(values),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: usersKey });
      toast.success("User created successfully");
    },
    onError: (error: Error) => toast.error(error?.message || "Failed to create user"),
  });
}

export function useUpdateUser(id: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (values: UpdateUserFormValues) => usersApi.update(id, values),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: usersKey });
      toast.success("User updated successfully");
    },
    onError: (error: Error) => toast.error(error?.message || "Failed to update user"),
  });
}

export function useResetUserPassword(id: string) {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (password: string) => usersApi.resetPassword(id, password),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: usersKey });
      toast.success("Password reset successfully");
    },
    onError: (error: Error) => toast.error(error?.message || "Failed to reset password"),
  });
}

export function useDeleteUser() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => usersApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: usersKey });
      toast.success("User deleted successfully");
    },
    onError: (error: Error) => toast.error(error.message || "Failed to delete user"),
  });
}

export function useUserDeleteImpactQuery(id: string, options: { enabled?: boolean } = {}) {
  return useQuery({
    queryKey: [...userKey(id), "delete-impact"],
    queryFn: () => usersApi.getDeleteImpact(id),
    enabled: Boolean(id) && (options.enabled ?? true),
    staleTime: 0,
  });
}

export function useBulkDeleteUsers() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (ids: string[]) => usersApi.bulkDelete(ids),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: usersKey });
      const suffix = result.skippedSelf ? " (your own account was skipped)" : "";
      toast.success(`${result.count} user${result.count === 1 ? "" : "s"} deleted${suffix}`);
    },
    onError: (error: Error) => toast.error(error.message || "Failed to delete users"),
  });
}
